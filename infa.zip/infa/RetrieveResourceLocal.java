package com.hughes.bits.jupiter.model;

import java.io.Serializable;
import javax.persistence.*;

import java.math.BigDecimal;
import java.util.Date;





/**
 * The persistent class for the LOGICAL_RESC database table.
 *
 */
@Entity
@Table(name="TBL_LGCL_RSC")
public class LogicalRescJDO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="LGCL_RSC_ID_GENERATOR", sequenceName="LGCL_RSC_ID_SEQ", allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LGCL_RSC_ID_GENERATOR")
	@Column(name="LGCL_RSC_ID")
	private long lgclRscId;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="CRE_DT")
	private Date creDt;

	@Column(name="DVC_ID")
	private String dvcId;

	@Column(name="RSC_TYP")
	private String rscTyp;

	@Column(name="REASON_CD")
	private String reasonCd;

	@Column(name="OLD_SITE_TYPE")
	private String oldSiteType;

	@Column(name="ORDERED_BEAM_ID")
	private String orderBeamId;


	@Temporal( TemporalType.TIMESTAMP)
	@Column(name="VER_CLS_DT")
	private Date verClsDt;

    public Date getVerClsDt() {
		return verClsDt;
	}

	public void setVerClsDt(Date verClsDt) {
		this.verClsDt = verClsDt;
	}

	@Temporal( TemporalType.TIMESTAMP)
	@Column(name="VER_OPN_DT")
	private Date verOpnDt;

	private String san;

    @Temporal( TemporalType.TIMESTAMP)
	@Column(name="UPD_DT")
	private Date updDt;

	@Column(name="USG_ST_CD")
	private BigDecimal usgStCd;
	
	@Column(name="OLD_REASON_CD")
	private String oldReasonCd;
	
	@Column(name="ORDERED_SAT_ID")
	private Integer ordSatId=0;
	
	@Column(name="NMS_ID")
	private int nmsId;
	
	@Column(name="EXTRA_FIELDS")
	private String extraFields;
	
    public LogicalRescJDO(Date creDt,Date verOpnDt,Date updDt,Date verClsDt,String san,String dvcId,String rscTyp,BigDecimal usgStCd) {
    	this.creDt =creDt;
    	this.verOpnDt = verOpnDt;
    	this.updDt = updDt;
    	this.verClsDt = verClsDt;
    	this.dvcId = dvcId;
    	this.san = san;
    	this.rscTyp = rscTyp;
    	this.usgStCd = usgStCd;
    }

    public LogicalRescJDO(){

    }

	public long getLgclRscId() {
		return this.lgclRscId;
	}

	public void setLgclRscId(long lgclRscId) {
		this.lgclRscId = lgclRscId;
	}

	public Date getCreDt() {
		return this.creDt;
	}

	public void setCreDt(Date creDt) {
		this.creDt = creDt;
	}

	public String getDvcId() {
		return this.dvcId;
	}

	public void setDvcId(String dvcId) {
		this.dvcId = dvcId;
	}

	public String getRscTyp() {
		return this.rscTyp;
	}

	public void setReasonCd(String reasonCd) {
		this.reasonCd = reasonCd;
	}

     public String getReasonCd() {
		return this.reasonCd;
	}

	public void setRscTyp(String rscTyp) {
		this.rscTyp = rscTyp;
	}


	public String getSan() {
		return this.san;
	}

	public void setSan(String san) {
		this.san = san;
	}

	public Date getUpdDt() {
		return this.updDt;
	}

	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}

	public BigDecimal getUsgStCd() {
		return this.usgStCd;
	}

	public void setUsgStCd(BigDecimal usgStCd) {
		this.usgStCd = usgStCd;
	}

	public Date getVerOpnDt() {
		return verOpnDt;
	}

	public void setVerOpnDt(Date verOpnDt) {
		this.verOpnDt = verOpnDt;
	}

	public String getOldSiteType() {
		return oldSiteType;
	}

	public void setOldSiteType(String oldSiteType) {
		this.oldSiteType = oldSiteType;
	}

	public String getOrderBeamId() {
		return orderBeamId;
	}

	public void setOrderBeamId(String orderBeamId) {
		this.orderBeamId = orderBeamId;
	}
	
	public void setOldReasonCd(String oldReasonCd) {
		this.oldReasonCd = oldReasonCd;
	}

     public String getOldReasonCd() {
		return this.oldReasonCd;
	}

  	public Integer getOrderedSatId() {
 		return this.ordSatId;
 	}

 	public void setOrderedSatId(Integer ordSatId) {
 		this.ordSatId = ordSatId;
 	}
	
	public int getNmsId() {
 		return this.nmsId;
 	}

 	public void setNmsId(int nmsId) {
 		this.nmsId = nmsId;
 	}
 	
	public void setExtraFields(String extraFields) {
		this.extraFields = extraFields;
	}

     public String getExtraFields() {
		return this.extraFields;
	}

}