package com.infa.app;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.infa.util.InfaDasboardUtil;

@Path("/dashboard")
public class InfaServiceImpl {

		@GET
		@Path("/login1")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response login( @PathParam("org")String org) throws MalformedURLException, IOException {
			
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Content-Type","application/json");
			headers.put("Accept","application/json");
			String body = "{\"@type\": \"login\",\"username\": \"nidhi.kalamkar@hughes.com."+org.trim()+"\",\"password\": \"Hns@MTS2\"}";
			String result = InfaDasboardUtil.GetExternalResponse("https://app.informaticaondemand.com/ma/api/v2/user/login", body, "POST",headers);
			try {
				JSONObject json = new JSONObject(result);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return Response.status(200).entity(result).build();

		}
		
		@GET
		@Path("/login/{org}")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response loginOtheruser(@PathParam("org")String org) throws MalformedURLException, IOException, JSONException {
			
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Content-Type","application/json");
			headers.put("Accept","application/json");
			String body = "{\"@type\": \"login\",\"username\": \"nidhi.kalamkar@hughes.com."+org.trim()+"\",\"password\": \"Hns@MTS2\"}";
			String result = InfaDasboardUtil.GetExternalResponse("https://app.informaticaondemand.com/ma/api/v2/user/login", body, "POST",headers);
				JSONObject res = new JSONObject(result);
				JSONObject responseToSend = new JSONObject();
				
				if (!result.isEmpty()&& res.has("icSessionId"))
				{
					try {
						responseToSend.put("status","Success");
						responseToSend.put("message","Login Success");
						responseToSend.put("icSessionId",res.get("icSessionId"));
						return Response.status(200).entity(responseToSend.toString()).build();
						
					} catch (JSONException e) {
						responseToSend.put("status","Fail");
						responseToSend.put("message","Login unsuccessful");
						responseToSend.put("exception",e.getMessage());
						e.printStackTrace();
						return Response.status(200).entity(responseToSend.toString()).build();
					}
				}
				else
				{
					responseToSend.put("status","Fail");
					responseToSend.put("message","Login unsuccessful");
					return Response.status(200).entity(responseToSend.toString()).build();
				}
			
			}

		
		@GET
		@Path("/logout/{id}")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response logout(@PathParam("id") String icSessionId) throws MalformedURLException, IOException {
			
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Content-Type","application/json");
			headers.put("Accept","application/json");
			headers.put("icSessionId",icSessionId);
			String body = "";
			String response = InfaDasboardUtil.GetExternalResponse("https://app3.informaticacloud.com/saas/api/v2/user/logout", body, "POST",headers);
			System.out.println(response);
			
			try {
				JSONObject json = new JSONObject(response);
				System.out.println("status: " + json.getString("Status"));
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return Response.status(200).entity(response).build();

		}
	
		@GET
		@Path("/startJob/{taskName}/{taskType}")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response startJob( @PathParam("taskName")String taskName, @PathParam("taskType")String taskType,@PathParam("icSessionId") String icSessionId) throws MalformedURLException, IOException, JSONException {
			
		
		/*	HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Content-Type","application/json");
			headers.put("Accept","application/json");
			
			String response = InfaDasboardUtil.GetExternalResponse("http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/login", "", "GET",headers);
			
			JSONObject json = new JSONObject(response.toString());
			
			System.out.println("icSessionId: " + json.getString("icSessionId"));
			
			String icSessionId= json.getString("icSessionId");*/
			
			HashMap<String ,String> inputheaders = new HashMap<String, String>();
			inputheaders.put("Content-Type","application/json");
			inputheaders.put("Accept","application/json");
			inputheaders.put("icSessionId",icSessionId.trim());
			//System.out.println(response);
			
			String body = "{\"@type\": \"job\",\"taskName\": \""+taskName+"\",\"taskType\": \""+taskType+"\"}";
			
			String startJobResponse = InfaDasboardUtil.GetExternalResponse("https://app3.informaticacloud.com/saas/api/v2/job", body, "POST",inputheaders);
		
			JSONObject json1 = new JSONObject(startJobResponse);
			System.out.println("runId: " + json1.getString("runId"));
			String runId = json1.getString("runId");
			String taskId = json1.getString("taskId");
			System.out.println("taskName: " + json1.getString("taskName"));
			System.out.println("taskId: " + json1.getString("taskId"));
			
		/*	String activityLogResponse = "";
			
			if(!runId.isEmpty())
			{
				activityLogResponse = InfaDasboardUtil.GetExternalResponse("http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/activityLog/"+icSessionId.trim()+"/"+runId+"/"+taskId,"", "GET",headers);
			}*/

			return Response.status(200).entity(startJobResponse).build();
	}
		
		@POST
		@Path("/callback")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response callback() throws MalformedURLException, IOException {
			
			//request.toString();
			return Response.ok().build();

		}
		
		@GET
		@Path("/activityLog/{id}/{runId}/{taskId}")
    	@Consumes("*/*")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response monitor( @PathParam("id")String icSessionId, @PathParam("runId")String runId,@PathParam("taskId")String taskId) throws MalformedURLException, IOException, JSONException {
					
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Accept","application/json");
			headers.put("icSessionId",icSessionId.trim());
			String response="[]";
			JSONObject responseToSend = new JSONObject();
			//while(response.equals("[]") || response.equals("{}"))
		//{
			//	try {
			//		Thread.sleep(10000);
			//	} catch (InterruptedException e) {
					// TODO Auto-generated catch block
			//		e.printStackTrace();
			//	}
				response = InfaDasboardUtil.GetExternalResponse("https://app3.informaticacloud.com/saas/api/v2/activity/activityLog?taskId="+taskId+"&runId="+runId,"","GET",headers);
				System.out.println("Response from activity log"+response);
			//}
				response=response.substring(1, response.length()-1);
				
				if (response.equals("[]") || response.equals("{}")|| response.isEmpty() || response == null)
				{
					responseToSend.put("status","Success");
					responseToSend.put("message","The task is still running.Please check in a few minutes.");
					responseToSend.put("runId",runId);
					responseToSend.put("taskId",taskId);
					responseToSend.put("icSessionId",icSessionId);
					return Response.status(200).entity(responseToSend.toString()).build();
				}
				else {
				JSONObject json = new JSONObject(response.toString());
				System.out.println("state: " + json.getString("state"));
				String status = json.getString("state");
				if(status.equals("1"))
				{
					responseToSend.put("status","Success");
					responseToSend.put("message","The was completed succesfully.");
				}
				else
				{
					responseToSend.put("status",status=json.getString("state")=="3"?"faliure":"warning");
					responseToSend.put("message","The task either failed or executed with warning. Please check with DI team.");
					responseToSend.put("entries",json.getJSONArray("entries"));
				}
			System.out.println("respond to send"+ responseToSend.toString());
			return Response.status(200).entity(responseToSend.toString()).build();
			}
		}
		
		@GET
		@Path("/startCatalog")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response startCatalog() throws MalformedURLException, IOException, JSONException {
			
		
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("Content-Type","application/json");
			headers.put("Accept","application/json");
			
			String response = InfaDasboardUtil.GetExternalResponse("http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/login", "", "GET",headers);
			
			JSONObject json = new JSONObject(response.toString());
			
			System.out.println("icSessionId: " + json.getString("icSessionId"));
			
			String icSessionId=json.getString("icSessionId");
			
			HashMap<String ,String> inputheaders = new HashMap<String, String>();
			inputheaders.put("Content-Type","application/json");
			inputheaders.put("Accept","application/json");
			inputheaders.put("icSessionId",icSessionId.trim());
			//System.out.println(response);
			
			String body = "{\"@type\": \"job\",\"taskName\": \"TF_DSS_SF_CTLG_SYNC\",\"taskType\": \"WORKFLOW\"}";
			
			String startJobResponse = InfaDasboardUtil.GetExternalResponse("https://app3.informaticacloud.com/saas/api/v2/job", body, "POST",inputheaders);
		
			JSONObject json1 = new JSONObject(startJobResponse);
			System.out.println("runId: " + json1.getString("runId"));
			String runId = json1.getString("runId");
			String taskId = json1.getString("taskId");
			System.out.println("taskName: " + json1.getString("taskName"));
			System.out.println("taskId: " + json1.getString("taskId"));
			
		//	String activityLogResponse = "";
			JSONObject responseToSend = new JSONObject();
			if(!runId.isEmpty())
			{
				responseToSend.put("status","Success");
				responseToSend.put("message","The task was run sccessfully.The task usually take 2-3 minutes to complete.Please click the \"Task Status\" button to check the status of the task.");
				responseToSend.put("runId",runId);
				responseToSend.put("taskId",taskId);
				responseToSend.put("icSessionId",icSessionId);
				return Response.status(200).entity(responseToSend.toString()).build();
				//activityLogResponse = InfaDasboardUtil.GetExternalResponse("http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/activityLog/"+icSessionId.trim()+"/"+runId+"/"+taskId,"", "GET",headers);
			}
			else {
				responseToSend.put("status","Failed");
				responseToSend.put("message","The task failed to execute.Please contact DI team.");
				return Response.status(200).entity(responseToSend).build();
			}
							
			

	}
		
		@GET
		@Path("/conn/sfdc/{org}/{id}")
		@Produces({ MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML })
		public Response getconnection( @PathParam("org")String org , @PathParam("id")String icSessionId) throws MalformedURLException, IOException, JSONException {
			
			String SFDC_Conn_name = "CONN_SFDC_NAD";
			JSONObject responseToSend = new JSONObject();
			
			HashMap<String ,String> headers = new HashMap<String, String>();
			headers.put("icSessionId",icSessionId);
			headers.put("Accept","application/json");
			headers.put("Content-Type","application/json");
			
			if(org.toUpperCase().startsWith("B"))
			{
				SFDC_Conn_name = "CONN_SFDC_BRZ";
			}
			else if(org.toUpperCase().startsWith("Y"))
			{
				SFDC_Conn_name = "CONN_SFDC_YAH";
			}
			else if (org.toUpperCase().startsWith("S"))
			{
				SFDC_Conn_name = "CONN_SFDC_SAM";
			}

			String result = InfaDasboardUtil.GetExternalResponse("https://app3.informaticacloud.com/saas/api/v2/connection/name/"+SFDC_Conn_name, "", "GET",headers);
			System.out.println(result);
			/*try {
				JSONObject json = new JSONObject(result);
				responseToSend.put("status","Success");
				responseToSend.put("sfsandbox",(String)json.getString("username"));
				responseToSend.put("connectionId",(String)json.getString("id"));
			} catch (JSONException e) {
				responseToSend.put("status","Failed");
				responseToSend.put("message","Could not fetch connection details");
				e.printStackTrace();
			}*/
			
			return Response.status(200).entity(result).build();

		}
		
}
