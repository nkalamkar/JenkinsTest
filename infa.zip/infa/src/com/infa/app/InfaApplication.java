package com.infa.app;

import java.util.*;
import javax.ws.rs.core.Application;

public class InfaApplication extends Application {

	private Set<Object> singletons = new HashSet<Object>();

	public InfaApplication() {
		singletons.add(new InfaServiceImpl());
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
