package com.infa.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

public class InfaDasboardUtil {

	public static String GetExternalResponse(String endurl, String reqBody,String method,HashMap<String,String> requestHeaders) throws IOException,MalformedURLException {
		
		StringBuffer mockyresponse = null;
		try {
			BufferedReader bf = null;
			URL urlobj;
			HttpURLConnection con;
			
			urlobj = new URL(endurl);
			con = (HttpURLConnection) urlobj.openConnection();
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestMethod(method);
			
			for(String s: requestHeaders.keySet()){
				con.setRequestProperty(s, requestHeaders.get(s));
			}
			con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");			
			if (method.equalsIgnoreCase("post")) {
				
				OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
				writer.write(reqBody);
				writer.close();
			}
			
			bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line;
			mockyresponse = new StringBuffer();
			
			while ((line = bf.readLine()) != null) {
				mockyresponse.append(line);
			}
				
			bf.close();
			//System.out.println("This is mocky response"+mockyresponse.toString());
			return mockyresponse.toString();
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}

	}
	
	}
