var api_para = angular.module('InfaApp', []);

api_para
		.controller('InfaController',function($scope, $http, $window) {
$scope.org= null;		
$scope.infaOrg=["dev","sit","sit2","pqt","pqt2","otb","otb2","prd","bdev","bsit","bsit2","bpqt","bpqt2","botb","botb2","bprd","ydev","ysit","ysit2","ypqt","ypqt2","yotb","yotb2","yprd"]
					
				$scope.login = function(x) {
					console.log("in the login function in controller");
					console.log("Value of x is"+$scope.x);
					console.log("Value of org is"+$scope.org);
					if (x === null)
						{
						 $scope.errorMsg = "Please choose the informatica enviornment first!"
						}
					var req = {
						method : 'GET',
						url : 'http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/login/dev',// +dev,
						headers : {
							'Content-Type' : 'application/json'
						},
					}
					$http(req).then(function success(response) {
						console.log("logged in ");
						console.log(response.status);
						$scope.loginSuccess=response.data.message;
						$scope.id = response.data.icSessionId;
						console.log("message is -> "+$scope.loginSuccess);
						console.log("message is -> "+$scope.id);
						if(response.data.status === 'Success')
						{
							$scope.conn($scope.id);
						}
					}, function errorCallBack(response) {
						$scope.successmsg = 'OOPS! Looks like there was some error!.'
						console.log("response-->" + $scope.successmsg);
					})
				};
				
				$scope.conn = function(infaOrg,id) {
					
					console.log("in the conn");
					if ($scope.infaOrg === null)
						{
						 $scope.errorMsg = "Please choose the informatica enviornment first!"
						}
					var req = {
						method : 'GET',
						url : 'http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/conn/sfdc/dev'+'/'+$scope.id,
						headers : {
							'Content-Type' : 'application/json'
						},
					}
					$http(req).then(function success(response) {
						console.log("conndetailes fetched ");
						console.log(response.status);
						$scope.SFDC_username=response.data.username;
						console.log("message is -> "+$scope.SFDC_username);

					}, function errorCallBack(response) {
						$scope.successmsg = 'OOPS! Looks like there was some error!.'
						console.log("response-->" + $scope.successmsg);
					})
					
					
				};
		
				$scope.runInfaTask = function() {
						console.log("in the controller");
						$scope.runCatalogButton = false;

						var req = {
							method : 'GET',
							url : 'http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/startCatalog',
							headers : {
								'Content-Type' : 'application/json'
							},
						}
						if($scope.infaOrg != null)
						{

							$http(req).then(function success(response) {
								console.log("Task run");
								console.log(response.status);
								$scope.TaskResponse = response.data;
								console.log($scope.TaskResponse);
								$scope.successmsg = response.data.message;
								console.log("message is -> "+$scope.successmsg);
								if(response.data.status === 'Success')
									{
									$scope.getTaskStatus($scope.TaskResponse);
								}
							}, function errorCallBack(response) {
								$scope.successmsg = 'OOPS! Looks like there was some error!.'
								console.log("response-->" + $scope.successmsg);
							})
						}
						else{
							
							$scope.errorMsg = "Please choose the informatica enviornment first and login!"
						}
						
					};


					$scope.getTaskStatus = function(TaskResponse) {
						console.log("in the get status");
						var para = TaskResponse.icSessionId+'/'+TaskResponse.runId+'/'+TaskResponse.taskId;
						var req_status = {
							method : 'GET',
							url : 'http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/activityLog/'+para,
							headers : {
								'Accept' : 'application/json',
								'Content-Type' : 'application/json'
							},
						}
						$http(req_status).then(function success(response) {
							console.log("Getting Task run status");
							console.log(response.status);
							$scope.TaskResponse = response.data;
							$scope.successmsg = response.data.message
							if($scope.successmsg === 'The task is still running.Please check in a few minutes.')
								{
								$scope.getTaskStatus($scope.TaskResponse);
								}
							}, function errorCallBack(response) {
									$scope.successmsg = 'OOPS! Looks like there was some error!'
									console.log("response-->" + $scope.successmsg);
						})
					};
					
					$scope.logout = function(TaskResponse){
						console.log("In logout function.");
						var req_logout ={
								method:'GET',
								url: 'http://localhost:9090/infa-0.0.1-SNAPSHOT/rest/dashboard/logout/'+$scope.id,
								headers:{
									'Accept': 'application/json'
								},
						}
						$http(req_logout).then(function success(response) {
							console.log("Getting Task run status");
							console.log(response.status);
							$scope.TaskResponse = response.data;
							//$scope.successmsg = response.data.message
							console.log(response.data.message);
							}, function errorCallBack(response) {
									$scope.successmsg = 'OOPS! Looks like there was some error!'
									console.log("response-->" + $scope.successmsg);
						})
					};
		});